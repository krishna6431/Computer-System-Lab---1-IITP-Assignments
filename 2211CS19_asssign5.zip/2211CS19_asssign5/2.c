/**************************
Computer lab Assignment : 5
Problem 2
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
***************************/
#include <stdio.h>

//main function starts here
int main()
{   
    //taking input
    int arg1,arg2,temp_arg;
    printf("Declare two integer variables arg1 and arg2 and assign them 51 and 15 respectively:");
    printf("\nEnter two integer number : ");
    printf("\narg1=");
    scanf("%d",&arg1);
    printf("\narg2=");
    scanf("%d",&arg2);
    //swapping contents of register using inline assembly method
    
    //assigning content of arg1 to temp_arg register
    __asm__("movl %1,%%eax;"
        "movl %%eax,%0;"
        :"=r"(temp_arg)
        :"r"(arg1)
        :"%eax"
        );
        
    //assigning content of arg2 to arg1 register
    __asm__("movl %1,%%eax;"
        "movl %%eax,%0;"
        :"=r"(arg1)
        :"r"(arg2)
        :"%eax"
        );
        
    //assigning content of temp_arg to arg2 register
    __asm__("movl %1,%%eax;"
        "movl %%eax,%0;"
        :"=r"(arg2)
        :"r"(temp_arg)
        :"%eax"
        );
    
    //printing swapped ans
    printf("\narg1 = %d\narg2 = %d",arg1,arg2);
    return 0;
}


/**************************
Computer lab Assignment : 5
Problem 1
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
***************************/

#include <stdio.h>
#include <stdlib.h>

int countAns = 0;
int print_check = 0;
int comma_print = 0;

//printing answers stored for each possible subsets
void printValues(int A[], int size){
   printf("[");
   for (int i = 0; i < size-1; i++) {
      printf("%d,",A[i]);
   }
   printf("%d]",A[size-1]);
}

//utitlity function that finds all the subsets (with repetition that sum equalt to target)
void solveUtility(int s[], int t[], int s_size, int t_size, int sum, int ite, int const target_sum){
   //printing ans
   if (target_sum == sum) {
      if(print_check==1){
          comma_print++;
          printValues(t, t_size);
          if(comma_print!=countAns){
            printf(",");
          }
      }
      //counting ans
      if(print_check==0){
        countAns++;
      }
      return;
   }
   //base case when currSum is > target or index reaches end of given set
   if(sum > target_sum || ite==s_size){
      
      return;
   }
    
    //recursive call for each possibility
    for (int i = ite; i < s_size; i++) {
        t[t_size] = s[i];
        solveUtility(s, t, s_size, t_size + 1, sum + s[i], i, target_sum);
    }
  
}

//solve function 
void solve(int s[], int size, int target_sum){
   //vector that stores answers for each possible set
   int* tuplet_vector = (int*)malloc(size * sizeof(int));
   solveUtility(s, tuplet_vector, size, 0, 0, 0, target_sum);
   free(tuplet_vector);
}

//main function starts here
int main(){
   //input no of sack
   int numberOfSack;
   printf("Number of items in the sack: ");
   scanf("%d",&numberOfSack);
   //storing each costs
   int costSack[numberOfSack];
   printf("\nCost of each item: ");
   for(int i = 0 ; i < numberOfSack ; i++){
       scanf("%d",&costSack[i]);
   }
   //target sum
   int target;
   printf("\nCost of withdrawal: ");
   scanf("%d",&target);
   printf("\nThe set is ");
   solve(costSack, numberOfSack, target);
   //printing total count of ans
   printf("\nNo of unique lists of items with a total cost %d: %d",target,countAns);
   print_check = 1;
   //printing each possible set
   printf("\nList of all the unique possible combinations of items: ");
   solve(costSack, numberOfSack, target);
   countAns = 0;
   print_check = 0;
   comma_print = 0;
   return 0;
   //thanking you so much
}


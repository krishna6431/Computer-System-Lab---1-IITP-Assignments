//including required header file
#include <stdio.h>
#include <string.h>
//main function starts here
int main()
{
    //taking input array
    char inputArr[1000];
    printf("Enter the Message = ");
    scanf("%s", inputArr);
    //finding length of the char array
    int length = strlen(inputArr);
    //taking input key
    printf("\nEnter the Key = ");
    int key[4];
    //taking all the key as input
    for (int i = 0; i < 4; i++)
    {
        scanf("%d", &key[i]);
    }
    //declaring result array for storing ans
    int result[1000];
    for (int i = 0; i < length; i++)
    {
        result[i] = (inputArr[i] - 'a' + 1) + key[i % 4];
    }
    //printing answer
    printf("\nString is : [");
    for (int i = 0; i < length - 1; i++)
    {
        printf("%d,", result[i]);
    }
    printf("%d", result[length - 1]);
    printf("].");
    //thank you so much
    return 0;
}

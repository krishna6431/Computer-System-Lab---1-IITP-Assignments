//include file 
#include <stdio.h>
//main function starts here
int main()
{
    //taking input integer(prime number)
    int num;
    printf("Input: ");
    scanf("%d", &num);
    //we have to find whether it contains 3 or not
    int key = 3;
    //storing ans state
    int flag = 0;
    while (num)
    {
        //finds first digit
        int rem = num % 10;
        if (rem == key)
        {
            //true state
            flag = 1;
        }
        //reducing the number by dividing with 10
        num /= 10;
    }
    printf("\nOutput: ");
    //true state
    if (flag)
    {
        printf("1");
    }
    else
    {
        printf("0");
    }
    return 0;
    //thank you so much
}

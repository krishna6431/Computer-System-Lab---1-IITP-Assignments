// Indian Institute of Technology Patna
// Krishna Kant Verma
// MidSem Quiz of Foundation of Computer System Lab
// Roll No: 2211cs19

#include <stdio.h>

//Structure for taking input (arrival time , burst time)
struct processInfo
{
	int arrivalTime;
	int burstTime;
	int pid;
};

//structure for printing output (arrival time , burst time , tat , wt , pid)
struct roundRobin
{
	int arrivalTime;
	int burstTime;
	int turnaroundTime;
	int waitingTime;
	int pid;
};

//sorting arrival time in accordance to arrival time
void sortInputArrivalTime(struct processInfo input[150], int size)
{
	int i, j;
	struct processInfo buffer;

	for (i = 0; i < size - 1; i++)
	{
		for (j = 0; j < (size - 1 - i); j++)
		{
			if (input[j].arrivalTime > input[j + 1].arrivalTime)
			{
				buffer = input[j];
				input[j] = input[j + 1];
				input[j + 1] = buffer;
			}
		}
	}
}

// sorting for output 
void sortOutputArrivalTime(struct roundRobin input[150], int size)
{
	int i, j;
	struct roundRobin buffer;

	for (i = 0; i < size - 1; i++)
	{
		for (j = 0; j < (size - 1 - i); j++)
		{
			if (input[j].arrivalTime > input[j + 1].arrivalTime)
			{
				buffer = input[j];
				input[j] = input[j + 1];
				input[j + 1] = buffer;
			}
		}
	}
}

//main function starts from here
int main()
{
	int i, noOfProcess, total = 0, x, counter = 0, timeQuantum;
	int totalWaitTime = 0, totalTurnaroundTime = 0, buffer[100];
	float averageTotalWaitTime, averageTotalTurnaroundTime;
	
    //creating struct for pcbs
	struct processInfo pcb[100];
	struct roundRobin schedule[100];
	int ganttChart[100];
	int gptr = 0;
	int s_idx = 0;
	
	//taking input no of processes
	printf("Enter Number Of Processes:");
	scanf("%d", &noOfProcess);
	x = noOfProcess;
	
	//taking input all the details
	for (int i = 0; i < noOfProcess; i++)
	{
		printf("\nEnter arrival time and Burst time for Process P[%d]:", i);
		scanf("%d", &pcb[i].arrivalTime);
		scanf("%d", &pcb[i].burstTime);
		pcb[i].pid = i;
	}
    
    //taking input quantum time
	printf("\nEnter Time Quantum:");
	scanf("%d", &timeQuantum);
	
	//sorting according to arrival time input
	sortInputArrivalTime(pcb, noOfProcess);
	
	for (int i = 0; i < noOfProcess; i++)
	{
		buffer[i] = pcb[i].burstTime;
	} 
	
	printf("\nExpected Output in accordance to Sample Input");
	//running roundrobin scheduling algorithm
	for (total = 0, i = 0; x != 0;)
	{
		if (buffer[i] <= timeQuantum && buffer[i] > 0)
		{
		    ganttChart[gptr++] = total;
			total = total + buffer[i];
			buffer[i] = 0;
			counter = 1;
			ganttChart[gptr++] = pcb[i].pid;
		    ganttChart[gptr++] = total;
		}
		else if (buffer[i] > 0)
		{
		    ganttChart[gptr++] = total;
			buffer[i] = buffer[i] - timeQuantum;
			total = total + timeQuantum;
		    ganttChart[gptr++] = pcb[i].pid;
		    ganttChart[gptr++] = total;
		}
		if (buffer[i] == 0 && counter == 1)
		{
		    //decrementing processes
			x--;
			//storing all the details of that process
			schedule[s_idx].arrivalTime = pcb[i].arrivalTime;
			schedule[s_idx].burstTime = pcb[i].burstTime;
			schedule[s_idx].turnaroundTime = total - pcb[i].arrivalTime;
			schedule[s_idx].waitingTime = total - pcb[i].arrivalTime - pcb[i].burstTime;
			schedule[s_idx].pid = pcb[i].pid;
			s_idx++;
			totalWaitTime = totalWaitTime + total - pcb[i].arrivalTime - pcb[i].burstTime;
			totalTurnaroundTime = totalTurnaroundTime + total - pcb[i].arrivalTime;
			counter = 0;
		}
		if (i == noOfProcess - 1)
		{
			i = 0;
		}
		else if (pcb[i].arrivalTime <= total)
		{
			i++;
		}
		else
		{
			i = 0;
		}
	}
	//printing gantt chart
	printf("\n\nGantt Chart:\n");
	int j = 0;
    while(j < gptr){
        if(j==0){
            printf("%d -->",ganttChart[j++]);
        }
        else{
            printf(" %d -->",ganttChart[j++]);
        }
        printf(" P[%d] <--",ganttChart[j++]);
        j++;
    }
	printf(" %d",ganttChart[j-1]);
	//sorting according to arrival time for output purpose
	sortOutputArrivalTime(schedule, noOfProcess);
	//printing all the required details of process
	printf("\n\nP\tAT\tBT\tTAT\tWT");
	for (int i = 0; i < noOfProcess; i++)
	{
		printf("\nP%d\t%d\t%d\t%d\t%d", schedule[i].pid, schedule[i].arrivalTime, schedule[i].burstTime, schedule[i].turnaroundTime, schedule[i].waitingTime);
	}
	//printing overall stats of that process
	averageTotalWaitTime = totalWaitTime *1.0 / noOfProcess;
	averageTotalTurnaroundTime = totalTurnaroundTime *1.0 / noOfProcess;
	printf("\n\nAverage Waiting Time:%.2f", averageTotalWaitTime);
	printf("\nAvg Turnaround Time:%.2f", averageTotalTurnaroundTime);
	
	//thank you so much
	return 0;
}

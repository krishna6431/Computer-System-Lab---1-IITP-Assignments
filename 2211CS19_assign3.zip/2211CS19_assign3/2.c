/******************************************************************************
Computer lab Assignment : 3 Ques 2
Problem 2
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/
#include <stdio.h>
#include <string.h>

typedef struct student
{
    char name[50];
    int rollno;
} stud;

// main function starts here
int main()
{

    // taking input in required format as per given representation
    int testcase;
    printf("Number of test cases: ");
    scanf("%d", &testcase);

    // function runs for all testcases
    while (testcase--)
    {
        int n;
        printf("Number of students: ");
        scanf("%d", &n);
        stud data[n];
        for (int i = 0; i < n; i++)
        {
            printf("Name: ");
            scanf("%s", data[i].name);
            printf("Roll: ");
            scanf("%d", &data[i].rollno);
        }
        char key;
        scanf("%c", &key);
        printf("Sorting key? (‘N’ for name/ ‘R’ for roll number): ");
        scanf("%c", &key);

        if (key == 'N')
        {
            int i, j;
            stud temp;
            for (i = 1; i < n; i++)
            {
                for (j = 0; j < n - i; j++)
                {
                    if (strcmp(data[j].name, data[j + 1].name) > 0)
                    {
                        temp = data[j];
                        data[j] = data[j + 1];
                        data[j + 1] = temp;
                    }
                }
            }
        }
        else
        {
            int i, j;
            stud temp;
            for (i = 1; i < n; i++)
            {
                for (j = 0; j < n - i; j++)
                {
                    if (data[j].rollno > data[j + 1].rollno)
                    {
                        temp = data[j];
                        data[j] = data[j + 1];
                        data[j + 1] = temp;
                    }
                }
            }
        }
        printf("\n");
        for (int i = 0; i < n; i++)
        {
            printf("Name: %s ", data[i].name);
            printf("Roll: %d \n", data[i].rollno);
        }
    }

    // finally solved
    // Thank You So Much
    // https://in.linkedin.com/in/krishna6431
    return 0;
}
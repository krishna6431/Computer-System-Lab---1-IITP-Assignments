/******************************************************************************
Computer lab Assignment : 3 Ques 3
Problem 3
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/
#include <stdio.h>
#include <string.h>
char stk2[50];
int top2 = -1, MAX = 50;
int isEmpty()
{
	return top2 == -1;
}
int isFull()
{
	return top2 == MAX - 1;
}

char peek()
{
	return stk2[top2];
}

char pop()
{
	if (isEmpty())
		return -1;

	char ch = stk2[top2];
	top2--;
	return (ch);
}
void push(char op)
{
	if (isFull())
		printf("Stack Full!!!!");

	else
	{
		top2++;
		stk2[top2] = op;
	}
}

int prec(char c)
{
	if (c == '^')
		return 3;
	else if (c == '/' || c == '*')
		return 2;
	else if (c == '+' || c == '-')
		return 1;
	else
		return -1;
}
int ifoperand(char ch)
{
	return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z');
}
int infixToPostfix(char input[])
{
	int i, j = -1;
	char output[50];
	for (i = 0; input[i] != '\0'; ++i)
	{
		if (ifoperand(input[i]))
			output[++j] = input[i];
		else if (input[i] == '(')
			push(input[i]);
		else if (input[i] == ')')
		{
			while (!isEmpty() && peek() != '(')
				output[++j] = pop();
			if (!isEmpty() && peek() != '(')
				return -1;
			else
				pop();
		}
		else
		{
			while (!isEmpty() && prec(input[i]) <= prec(peek()))
				output[++j] = pop();
			push(input[i]);
		}
	}
	while (!isEmpty())
		output[++j] = pop();

	output[++j] = '\0';
	printf("\nThe Equivalent postfix expression is: ");
	printf("\nPostfix Expression: %s", output);
}

int balancedParanthesis(char expression[])
{
	int x = 0, i = 0;
	while (expression[i] != '\0')
	{
		if (expression[i] == '(')
		{
			x++;
		}

		else if (expression[i] == ')')
		{
			x--;
			if (x < 0)
				break;
		}
		i++;
	}
}
int main()
{

	char expression[50];
	printf("Enter Infix expression\n");
	fgets(expression, 50, stdin);

	if (balancedParanthesis(expression) == 0)
	{
		printf("Parentheses are balanced.\n");
		infixToPostfix(expression);
	}

	else
	{
		printf("Parentheses are not balanced.\n\n");
		printf("Aborting execution.\n");
	}
	// finally solved
	// Thank You So Much
	// https://in.linkedin.com/in/krishna6431
	return 0;
}
/******************************************************************************
Computer lab Assignment : 3 Ques 1
Problem 1
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/
#include <stdio.h>

// main function starts here
int main()
{

    // taking input in required format as per given representation
    int testcase;
    scanf("%d", &testcase);
    printf("Number of test cases: %d\n\n", testcase);

    // function runs for all testcases
    while (testcase--)
    {
        int n, ele;
        scanf("%d", &n);
        printf("Number of queues: %d\n", n);
        scanf("%d", &ele);
        printf("Number of elements in each queue: %d\n\n", ele);
        int qMatrix[n][ele + 1];
        for (int i = 0; i < n; i++)
        {
            printf("Enter elements of queue %d: \n", i + 1);
            for (int j = 0; j < ele; j++)
            {
                scanf("%d", &qMatrix[i][j]);
            }
        }
        printf("\nMaster Queue: ");
        for (int i = 0; i < n; i++)
        {
            qMatrix[i][ele] = -1;
        }
        int front_pointer[n];
        for (int i = 0; i < n; i++)
        {
            front_pointer[i] = 0;
        }
        int sum = 0;
        int first_bool = 1;
        int firstIdx;
        int lastIdx;
        while (sum != (n) * (ele))
        {
            int min = 9999999;
            int idx = -1;
            for (int k = 0; k < n; k++)
            {
                if (qMatrix[k][front_pointer[k]] == -1)
                {
                    continue;
                }
                if (qMatrix[k][front_pointer[k]] < min)
                {
                    idx = k;
                    min = qMatrix[k][front_pointer[k]];
                }
            }
            printf("%d ", min);
            sum += 1;
            front_pointer[idx]++;
            if (front_pointer[idx] == ele && sum != (n) * (ele) && first_bool)
            {
                firstIdx = idx + 1;
                first_bool = 0;
            }
            else if (sum == (n) * (ele))
            {
                lastIdx = idx + 1;
            }
        }

        printf("\nQueue %d gets emptied first\n", firstIdx);
        printf("Queue %d gets emptied last\n\n", lastIdx);
    }

    // finally solved
    // Thank You So Much
    // https://in.linkedin.com/in/krishna6431
    return 0;
}
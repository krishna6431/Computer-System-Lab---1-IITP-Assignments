/******************************************************************************
Computer lab Assignment : 1 Ques 1
Problem 1
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/
#include <stdio.h>
//function that computes gcd of two numbers
int solve_for_gcd(int a , int b){
    
    return b==0 ? a:solve_for_gcd(b,a%b);
}

//function that computes the binomial coefficient that is required for the line
int binomial_coefficient(int n, int k){
    int ans = 1;
    if(k > n-k){
        k = n-k;
    }
    
    for(int i = 0 ; i < k ; i++){
        ans = ans*(n-i);
        ans = ans/(i+1);
    }
    
    return ans;
}
//function that print the pascals traingle of the generated gcd
void solve_for_pascal(int num){
    
    for(int i = 0 ; i < num ; i++){
        for(int j = 0 ; j <= i ; j++){
            //it will check for each line number
            int check_ans = binomial_coefficient(i,j);
            printf("%d ",check_ans);
        }
        printf("\n");
    }
    
}

int main()
{
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    int a ,b;
    scanf("%d\n%d",&a,&b);
    int gcd = solve_for_gcd(a,b);
    solve_for_pascal(gcd);
    return 0;
}



/******************************************************************************
Computer lab Assignment : 1 
Problem 2
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/
#include<stdio.h>
#include<stdlib.h>
//node information of tree
typedef struct node{
    int val;
    struct node *left_ptr;
    struct node *right_ptr;
}node;

//function to create binary search tree 
node *create_bst(int *arr, int n){
    if(n==0)return NULL;
    else{
        //allocating memort to node
        node *root = malloc(sizeof(node));
        int i,j,m;
        int swap = 1;
        j = n-1;
        // sorting the given array to keep the work simple
        while(swap){
            swap =0;
            for(int i = 0 ; i < j ; i++){
                if(arr[i]>arr[i+1]){
                    int temp = arr[i];
                    arr[i] = arr[i+1];
                    arr[i+1] = temp;
                    swap = 1;
                }
            }
            --j;
        }
        m = (n-1)/2;
        //recursivly create binary search tree
        root->val = arr[m];
        root->left_ptr = create_bst(arr,m);
        root->right_ptr = create_bst(arr+m+1,n-m-1);
        return root;
    }
}

//function that solve the actual problem that is given in the question
int sum = 0;
int path[1000000];
int idx = 0;
void main_solve(struct node* root , int k){
    if(root==NULL)return;
    //right subtree calling
    if(abs((root->val) - k)&1){
        sum+=root->val;
        path[idx++] = root->val;
        main_solve(root->right_ptr,k);
    }
    // left subtree calling
    else{
        sum+=root->val;
        path[idx++] = root->val;
        main_solve(root->left_ptr,k);
    }
}

int main()
{
    //required input information
    int testcase;
    puts("Number of test cases: ");
    scanf("%d",&testcase);
    // puts("\n");
    while(testcase--){
        int n;
        puts("Number of elements: ");
        scanf("%d",&n);
        // puts("\n");
        int arr[n];
        for(int i = 0 ; i < n ; i++){
            scanf("%d",&arr[i]);
        }
        int k;
        puts("k=");
        scanf("%d",&k);
        node *bst_root = create_bst(arr,n); 
        main_solve(bst_root,k);
        printf("Sum of the path=%d\n",sum);
        sum=0;
        printf("Path= ");
        for(int i = 0 ; i < idx-1 ; i++){
            printf("%d -> ",path[i]);
        }
        printf("%d\n",path[idx-1]);
        idx=0;
    }
    return 0;
}




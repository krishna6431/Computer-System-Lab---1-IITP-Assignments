/******************************************************************************
Computer lab Assignment : 1 
Problem 2
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/
#include<stdio.h>
#include<stdlib.h>

//Function to Solve the Required Problem 
int main_solve (int *arr, int n, int order)
{
  if (order == 1) // for case 1
    {
      int curr, i, j, ans = 0;
      for (i = 1; i < n; i++)
	{
	  curr = arr[i];
	  for (j = i - 1; j >= 0; j--)
	    {
	      if (curr < arr[j])
		{
		  arr[j + 1] = arr[j];
		  ans++;
		}
	    else{
	        break;
	    }
	   }
	  arr[j + 1] = curr;
	}
      return ans;
    }
  else // for case 2
    {
      int curr, i, j, ans = 0;
      for (i = 1; i < n; i++)
	{
	  curr = arr[i];
	  for (j = i - 1; j >= 0; j--)
	    {
	      if (curr > arr[j])
		{
		  arr[j + 1] = arr[j];
		  ans++;
		}
	    else{
	        break;
	    }
	   }
	  arr[j + 1] = curr;
	}
      return ans;
    }

}

//main function 
int main ()
{
  int testcase;
  scanf ("%d", &testcase);
  while (testcase--)
    {
      int n;
      scanf ("%d", &n);
      int arr[n];
      for (int i = 0; i < n; i++)
	{
	  scanf ("%d", &arr[i]);
	}
      int order;
      puts ("Order (1 for ascending/2 for descending): ");
      scanf ("%d", &order);
      printf ("No of pops: %d", main_solve (arr, n, order));
    }
  return 0;

}



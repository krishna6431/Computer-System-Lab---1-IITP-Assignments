/******************************************************************************
Computer lab Assignment : 2 Ques 1
Problem 1
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>

//function that finds a number of digit in a given number
int getDigit(int n)
{
   int ans = 0;
   while (n > 0)
   {
       n = n / 10;
       ans++;
   }
   //return count of digit
   return ans;
}

//function that fills the ans array with the bcd representation
void get_bcd(int n, int bcd_array[])
{
   int i = 0,j=1,digit;
   while (n > 0)
   {
       digit = n % 10;
       n /= 10;
       //binary representation of quadruple using bitwise operators
       while (digit > 0)
       {
           bcd_array[i++] = digit & 1;
           digit = digit >> 1;
       }
       i = (j++) * 4;
   }
}

//main function starts here
int main(){

    //taking input in required format as per given representation
    int testcase;
    printf("Number of test cases: \n\n");
    scanf("%d",&testcase);
    
    //function runs for all testcases
    while(testcase--){
        //taking input no of bits
        int n;
        printf("Bits available? : \n");
        scanf("%d",&n);
        
        //taking input the given decimal number
        int d;
        printf("Decimal Number: \n");
        scanf("%d",&d);
        
        //finding the no of digits in given decimal number
        int digit = getDigit(d);
        
        //no of bits in bcd representation (4 times the no of digit)
        digit*=4;
        
        //if bits are insufficient to represent
        if(n < digit){
            printf("BCD equivalent: cannot be represented\n");
        }
        
        //for possible case
        else{
            int *ans = (int*)malloc(sizeof(int)*digit);
            //calling function to get bcd representation of given number
            get_bcd(d,ans);
            printf("BCD equivalent:");
            for(int i = digit-1 ; i >=0  ; i--){
                if((i+1)%4==0){
                    printf(" ");
                }
                printf("%d",ans[i]);
            }
            printf("\n");
        }
    }
    
    //finally solved
    //Thank You So Much
    //https://in.linkedin.com/in/krishna6431
    return 0;
}

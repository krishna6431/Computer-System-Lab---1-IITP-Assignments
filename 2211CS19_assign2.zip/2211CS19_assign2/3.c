/******************************************************************************
Computer lab Assignment : 2 Ques 3
Problem 3
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>

//function that return the number of digits in required number
int getDigit(int n)
{
   int ans = 0;
   while (n > 0)
   {
       n = n / 10;
       ans++;
   }
   //return count of digits in required number
   return ans;
}

//function that fills the ans array with the bcd representation
void get_bcd(int n, int bcd_array[])
{
   int i = 0,j=1,digit;
   while (n > 0)
   {
       digit = n % 10;
       n /= 10;
       //binary representation of quadruple using bitwise operators
       while (digit > 0)
       {
           bcd_array[i++] = digit & 1;
           digit = digit >> 1;
       }
       i = (j++) * 4;
   }
}

//main function starts from here
int main(){

    //taking input in required format as per given representation
    int testcase;
    printf("Number of test cases: \n\n");
    scanf("%d",&testcase);
    
    //running for all testcases
    while(testcase--){
        //taking input both the numbers
        int firstNumber,secondNumber;
        printf("First Number: \n");
        scanf("%d",&firstNumber);
        printf("Second Number: \n");
        scanf("%d",&secondNumber);
        
        //findind the ans
        int subtraction = firstNumber - secondNumber;
        int sign;
        
        //finding the sign bit of the final ans
        if(subtraction < 0){
            sign = 0;
        }
        else{
            sign = 1;
        }
        
        //find no of digits in all the numbers that are required
        int digitFirst = getDigit(firstNumber);
        int digitSecond = getDigit(secondNumber);
        int digitAns = getDigit(abs(subtraction));
        
        //total no of bits in the bcd representaion of numbers
        digitFirst*=4; // for input 1
        digitSecond*=4; // for input 2
        digitAns*=4; // for final ans
        
        //allocating space to store the bcd representation of all the numbers
        int *firstAns = (int*)malloc(sizeof(int)*digitFirst);
        int *secondAns = (int*)malloc(sizeof(int)*digitSecond);
        int *ans = (int*)malloc(sizeof(int)*digitAns);
        
        //representing the bcd representation
        get_bcd(firstNumber,firstAns);
        get_bcd(secondNumber,secondAns);
        get_bcd(abs(subtraction),ans);
        
        //printing the output in required format
        //for input first number
        printf("%d(",firstNumber);
        for(int i = digitFirst-1 ; i >=0 ; i--){
            if((i+1)%4==0 && i!=digitFirst-1){
                printf(" ");
            }
            printf("%d",firstAns[i]);
        }
        printf(") - ");
        printf("%d(",secondNumber);
        
        // for input second number
        for(int i = digitSecond-1 ; i >=0 ; i--){
            if((i+1)%4==0&& i!=digitSecond-1){
                printf(" ");
            }
            printf("%d",secondAns[i]);
        }
        
        /*inding extra bit required to append in begining if ans bit count is less than max of
        bit count of both the numbers */
        int m = digitFirst > digitSecond ? digitFirst : digitSecond;
        int appendbit = 0;
        
        //find no of extra bit required in begining
        if(digitAns < m){
            appendbit = m-digitAns;
        }
        
        //printing output in required fashion
        printf(") = %d(",subtraction);
        //printing sign of ans
        if(!sign){
            printf("- ");
        }
        
        //appending the bit
        for(int i = 0 ; i < appendbit ; i++){
            if((i)%4==0 && i!=0){
                printf(" ");
            }
            printf("0");
        }
        if(appendbit && subtraction!=0){
            printf(" ");
        }
        
        //printing final ans
        for(int i = digitAns-1 ; i >=0 ; i--){
            if((i+1)%4==0&& i!=digitAns-1){
                printf(" ");
            }
            printf("%d",ans[i]);
        }
        printf(")\n");
    }
    
    // finally solved
    //Thank You So Much
    //https://in.linkedin.com/in/krishna6431
    return 0;
}

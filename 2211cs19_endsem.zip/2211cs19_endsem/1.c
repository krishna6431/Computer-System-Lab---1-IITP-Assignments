//Name : Krishna Kant Verma
//Roll No : 2211CS19
//FOCS Lab End Semester Exam
//Email: krishna_2211cs19@iitp.ac.in
 
 //including header file
 #include <stdio.h>
  
 
 //function for swapping the numbers 
 void interchangePlace(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
  }
  
  //creating heap nature on array elements and balance them
  void balanceUsingHeap(int arr[], int n, int i) {
    
    //finding root left and right childeren logically
    int maximum = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
  
    if (l < n && arr[l] > arr[maximum])
      maximum = l;
  
    if (r < n && arr[r] > arr[maximum])
      maximum = r;
  
    if (maximum != i) {
      interchangePlace(&arr[i], &arr[maximum]);
      balanceUsingHeap(arr, n, maximum);
    }
  }
  
  //soting the previous days arrays to find median elements
  void medianSortUsingHeap(int arr[], int n) {
    // Building max heap 
    for (int i = n / 2 - 1; i >= 0; i--)
      balanceUsingHeap(arr, n, i);

    // sorting them
    for (int i = n - 1; i >= 0; i--) {
      interchangePlace(&arr[0], &arr[i]);
       
      // balanceUsingHeap root element to get highest element at root again
      balanceUsingHeap(arr, i, 0);
    }
  }
  
  //main function starts over here
  int main() {
        //taking input n and no of days
        int n,days;
        printf("n= ");
        scanf("%d",&n);
        printf("d= ");
        scanf("%d",&days);
        //taking input expenditure of the customer
        int expenditure[n];
        int notice = 0;
        printf("Expenditure= ");
        for(int i = 0 ; i < n ; i++){
            scanf("%d",&expenditure[i]);
        }
        //error case
        if(n < days){
            printf("Error: The number of traling days must be less than the number of days of transaction data.\n");
            return 0;
        }
        else{
            int temporary[days];
            for(int i = 0 ; i < days ; i++){
                temporary[i] = expenditure[i];
            }
            int firstRemove = 0;
            int k = 0;
            
            for(int i = days ; i < n ; i++){
            //balancing previous d expenditure
                medianSortUsingHeap(temporary,days);
                
                //finding median
                float median;
                if(days&1){
                    median = temporary[days/2];
                }
                else{
    
                    median = temporary[days/2] + temporary[(days-1)/2];
                    median = median/2.0;
                }
                //checking conditions
                if(expenditure[i] >= 2*median){
                    notice++;
                }
                
                //adding previous d expenditures
                for(int j = 0 ; j < days ; j++){
                    temporary[j] = expenditure[i-j];
                }
            }
        }
        //printing answers
        printf("\nTotal No of Notice: %d \n",notice);
        return 0;
        //thank you so much
  }

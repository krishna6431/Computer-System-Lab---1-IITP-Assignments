/******************************************************************************
Computer lab Assignment : 4
Problem 1
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int count = 0;

int areConsecutive(int *sort_temp, int n)
{
    for (int i = 1; i <= n; i++)
    {
        if (abs(sort_temp[i] - sort_temp[i - 1]) > 1)
        {
            continue;
        }
        else
        {
            return 1;
        }
    }
    return 0;
}

void countSubset(int *ar, int *temp, int n, int level, int index)
{
    if (index == n)
        return;

    int i, j;
    for (i = index; i < n; i++)
    {
        temp[level] = ar[i];
        int sort_temp[level + 1];
        for (j = 0; j <= level; j++)
        {
            sort_temp[j] = temp[j];
        }
        if (!areConsecutive(sort_temp, level))
        {
            count++;
        }
        countSubset(ar, temp, n, level + 1, i + 1);
    }
}

void printPowerSet(int *ar, int *temp, int n, int level, int index)
{
    if (index == n)
        return;

    int i, j;
    for (i = index; i < n; i++)
    {
        temp[level] = ar[i];
        int sort_temp[level + 1];
        for (j = 0; j <= level; j++)
        {
            sort_temp[j] = temp[j];
        }
        if (!areConsecutive(sort_temp, level))
        {
            printf("{");
            for (j = 0; j <= level; j++)
            {

                printf("%d", temp[j]);
                if (j != level)
                    printf(",");
            }
            printf("}");
            if (i == n - 1 && level == 0)
                continue;
            else
                printf(",");
        }
        printPowerSet(ar, temp, n, level + 1, i + 1);
    }
}

int main()
{

    int testcase;
    printf("Number of test cases: ");
    scanf("%d", &testcase);
    while (testcase--)
    {
        int n;
        printf("Number of students (n): ");
        scanf("%d", &n);
        int arr[n];
        for (int i = 0; i < n; i++)
        {
            arr[i] = i + 1;
        }
        int temp[100000] = {0};
        countSubset(arr, temp, n, 0, 0);
        printf("Number of ways a compatible batch can be chosen is: %d", count);
        printf("\nThe sets are: ");
        printPowerSet(arr, temp, n, 0, 0);
        printf("\nLargest batch: ");
        if (n % 2 == 0)
        {
            printf("{");
            for (int i = 1; i <= n; i += 2)
            {
                if (i == n - 1)
                {
                    printf("%d},", i);
                    continue;
                }
                printf("%d,", i);
            }
            printf("{");
            for (int i = 2; i <= n; i += 2)
            {
                if (i == n)
                {
                    printf("%d}", i);
                    continue;
                }
                printf("%d,", i);
            }
        }
        else
        {
            printf("{");
            for (int i = 1; i <= n; i += 2)
            {
                if (i == n)
                {
                    printf("%d}", i);
                    continue;
                }
                printf("%d,", i);
            }
        }
        count = 0;
        printf("\n");
    }

    return 0;
}
/******************************************************************************
Computer lab Assignment : 4
Problem 2
Name: Krishna Kant Verma
Roll No: 2211CS19
Indian Institute of Technology (IIT Patna)
M.Tech - I
*******************************************************************************/
#include <stdio.h>

char arr[10000];
int length;
char result[10000];
char reverse[10000];
int k = 0;

// function that reverse
void reverseString(char *arr, int sz)
{
    int l = 0;
    for (int i = sz - 1; i >= 0; i--)
    {
        *(reverse + l) = *(arr + i);
        l++;
    }
    *(reverse + l) = '\n';
}

// function that concatnate
void concateString(char *arr, char *result)
{
    for (int i = 1; i < length; i++)
    {
        if (*(arr + i - 1) != *(arr + i))
            *(result + k) = *(arr + i);
        k++;
    }
}
int main()
{

    // Taking input length of string
    printf("Enter the length of string: ");
    scanf("%d", &length);

    // taking input string
    printf("Enter the string: ");
    scanf("%s", arr);

    // reversing the string using pointers
    reverseString(arr, length);

    *(result + k) = *arr;
    k++;

    // concatenating the string using pointers
    concateString(arr, result);

    // final printing of elements
    for (int j = k - 2; j >= 0; j--)
    {
        *(result + k) = *(result + j);
        k++;
    }

    // final print
    printf("Reversed Output: ");
    printf("%s", reverse);

    printf("Concatenated output: ");
    printf("%s", result);

    return 0;
}
// Krishna Kant Verma
//2211cs19
//FOCS Assignmnet 9
//Preemtive Shortest Job First Algorithm

#include <stdio.h>
void assignmentSolution()
{
	int p;
	printf("Number of Processes (P):\t");
	scanf("%d", &p);

	int arrivalTime[p + 1], burstTime[p + 1], temp[p + 1], completionTime[p + 1], waitingTime[p + 1], turnAroundTime[p + 1], responseTime[p + 1];
	int smallestPid;
	int i, count = 0, time;
	double waitTime = 0, turnaroundTime = 0, endTime;
	float avgWaitingTime = 0, avgTurnaroundTime = 0, res = 0, completeTime = 0;
	int ganttChart[100000];
	int gptr = 0;

	for (i = 0; i < p; i++)
	{
		responseTime[i] = 1e9;
		printf("Enter arrival time and burst time of process %d:\t", i + 1);
		scanf("%d %d", &arrivalTime[i], &burstTime[i]);
		temp[i] = burstTime[i];
	}
	int bt[p+1];
	for(int i = 0 ; i < p ; i++){
	    bt[i] = burstTime[i];
	}
	burstTime[p] = 99999;
	for (time = 0; count != p; time++)
	{
		smallestPid = p;
		ganttChart[gptr++] = time;
		for (i = 0; i < p; i++)
		{
			// printf("%d\t",arrivalTime[i]);
			if (arrivalTime[i] <= time && burstTime[i] < burstTime[smallestPid] && burstTime[i] > 0)
			{
				if (responseTime[i] == 1e9)
				{
					responseTime[i] = time;
				}
				smallestPid = i;
			}
		}
		ganttChart[gptr++] = smallestPid + 1;
		ganttChart[gptr++] = time+1;
		// 		printf("%d -->", smallestPid + 1);
		burstTime[smallestPid]--;
		if (burstTime[smallestPid] == 0)
		{
			count++;
			endTime = time + 1;
			completionTime[smallestPid] = endTime;
			waitTime += endTime - arrivalTime[smallestPid] - temp[smallestPid];
			waitingTime[smallestPid] = endTime - arrivalTime[smallestPid] - temp[smallestPid];
			turnaroundTime += endTime - arrivalTime[smallestPid];
			turnAroundTime[smallestPid] = endTime - arrivalTime[smallestPid];
		}
	}
	
	printf("\nExpected Output in accordance to Sample Input");
	
	printf("\n\nGantt Chart:\n");
	int j = 0;
	int pr = -1;
	
	while (j < gptr)
	{
	    if(pr!=ganttChart[j+1]){
    		
    		printf("%d -->", ganttChart[j]);
    		
    		printf(" P[%d] <--", ganttChart[j+1]);
    		pr = ganttChart[j+1];
    		
	    }
    	j=j+3;
	}
	printf("%d", ganttChart[j - 1]);
	
		
	printf("\nP_No\tAT\tBT\tTAT\tWT\n");
	for (int i = 0; i < p; i++)
	{
		printf("P%d\t%d\t%d\t%d\t%d\n",(i+1),arrivalTime[i],bt[i],turnAroundTime[i],waitingTime[i]);
		res += (responseTime[i] - arrivalTime[i]);
		completeTime += completionTime[i];
	}


	avgWaitingTime = waitTime / p;
	avgTurnaroundTime = turnaroundTime / p;
	
	printf("\nAverage Turnaround time: %.2f", avgTurnaroundTime);
	printf("\nAverage Waiting time: %.2f", avgWaitingTime);


}

int main()
{
	int testcase;
	printf("Number of test cases:\t");
	scanf("%d", &testcase);
	while (testcase--)
	{
		assignmentSolution();
	}
}

//Thanking you so much

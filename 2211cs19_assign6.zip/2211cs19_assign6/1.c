#include <stdio.h>
//main function starts from here
int main()
{
        //taking input testcase
	int testcase;
	printf("Number of test cases: ");
	scanf("%d", &testcase);
	while (testcase--)
	{
	        //input n
		int n;
		printf("\nNumber of Processes (P): ");
		scanf("%d", &n);
		//arrays for storing the results
		int arrival[n + 1], burst[n + 1], x[n + 1];
		int waiting[n + 1], turnaround[n + 1], completion[n + 1], response[n + 1];
		int i, j, smallest, count = 0, time, end;
		double avg_res = 0.0, avg_wait = 0.0, avg_tat = 0.0, avg_complete = 0.0;
               //init response time 
		for (int i = 0; i < n; i++)
		{
			response[i] = 99999;
		}

		for (int i = 0; i < n; i++)
		{
			printf("\nEnter arrival time and burst time of process %d:", (i + 1));
			scanf("%d %d", &arrival[i], &burst[i]);
		}

		for (i = 0; i < n; i++)
		{
			x[i] = burst[i];
		}
		for (time = 0; count != n; time++)
		{
			smallest = n;

			for (i = 0; i < n; i++)
			{
				if (arrival[i] <= time && burst[i] < burst[smallest] && burst[i] > 0)
				{
					if (response[i] == 99999)
					{
						response[i] = time;
					}
					smallest = i;
				}
			}
			burst[smallest]--;

			if (burst[smallest] == 0)
			{
				count++;
				end = time + 1;
				completion[smallest] = end;
				waiting[smallest] = end - arrival[smallest] - x[smallest];
				turnaround[smallest] = end - arrival[smallest];
			}
		}
		//printing in desired format
		for (i = 0; i < n; i++)
		{
			printf("\nProcess P%d (response, waiting, turnaround and completion time): %d, %d, %d, %d", (i + 1), response[i] - arrival[i], waiting[i], turnaround[i], completion[i]);
			avg_res += (response[i] - arrival[i]);
			avg_wait += waiting[i];
			avg_tat += turnaround[i];
			avg_complete += completion[i];
		}
        printf("\n");
		avg_res /= n;
		avg_wait /= n;
		avg_tat /= n;
		avg_complete /= n;
               //printing overall stats
		int check_avg_res = avg_res;
		int check_avg_wait = avg_wait;
		int check_avg_tat = avg_tat;
		int check_avg_complete = avg_complete;

		if (check_avg_res == avg_res)
		{
			printf("\nAverage response time: %d", check_avg_res);
		}
		else
		{

			printf("\nAverage response time: %.2lf", avg_res);
		}

		if (check_avg_wait == avg_wait)
		{
			printf("\nAverage waiting time: %d", check_avg_wait);
		}
		else
		{
			printf("\nAverage waiting time: %.2lf", avg_wait);
		}

		if (check_avg_tat == avg_tat)
		{
			printf("\nAverage turnaround time: %d", check_avg_tat);
		}
		else
		{

			printf("\nAverage turnaround time: %.2lf", avg_tat);
		}

		if (check_avg_complete == avg_complete)
		{
			printf("\nAverage completion time: %d", check_avg_complete);
		}
		else
		{
			printf("\nAverage completion time: %.2lf", avg_complete);
		}
	}

	return 0;
}
